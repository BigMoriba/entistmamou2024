<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center">
        <div class="row verif-ine-bloc">
                <h3 class="text-center verif-ine-h1"><?php echo e(__('ETAPE 3: Définir votre mot de passe !')); ?></h3>
                <div class="col">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <p class="text-center verif-ine-p"><?php echo e(__('Penser à mettre un mot de passe viable !')); ?></p>
                        <div class="row">
                            <div class="col-sm-3 mt-2">

                            </div>
                            <div class="col-sm-6 mt-2">
                                <label class="form-label text-label" for="motdepasse">Mot de passe :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="password" placeholder="<?php echo e(__('Mot de passe')); ?>">
                            </div>
                            <div class="col-sm-3 mt-2">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-3 mt-2">

                            </div>
                            <div class="col-sm-6 mt-2">
                                <label class="form-label text-label" for="confirmotdepasse">Confirmer mot de passe :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="password" placeholder="<?php echo e(__('Confirmer mot de passe')); ?>">
                            </div>
                            <div class="col-sm-3 mt-2">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-3 mt-2">

                            </div>
                            <div class="col-sm-6 mt-2">
                                <button class="btn verif-ine-submit">
                                    <span><?php echo e(__('Next')); ?></span>
                                    <i class="bi bi-check"></i>
                                </button>
                            </div>
                            <div class="col-sm-3 mt-2">

                            </div>
                        </div>
                    </form>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED MORIBA\Desktop\entistmamou\entistmamou\resources\views/etudiants/inscriptions/mot-de-passe.blade.php ENDPATH**/ ?>