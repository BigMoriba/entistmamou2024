<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center">
        <div class="row verif-ine-bloc">
                <h1 class="text-center verif-ine-h1"><?php echo e(__('Welcome')); ?></h1>
                <h3 class="text-center verif-ine-h1"><?php echo e(__('ETAPE 1: Vérification de l\'Identifiant National Etudiant (INE).')); ?></h3>
                <div class="col">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <p class="text-center verif-ine-p"><?php echo e(__('Veuillez entrer votre INE dans le champ ci-dessous:')); ?></p>
                        <div class="row">
                            <div class="col-sm-3 mt-2">
                                
                            </div>
                            <div class="col-sm-5 mt-2">
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('INE')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <button class="btn verif-ine-submit">
                                    <span><?php echo e(__('Soumettre')); ?></span>
                                    <i class="bi bi-check"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED MORIBA\Desktop\entistmamou\entistmamou\resources\views/etudiants/inscriptions/verif-ine.blade.php ENDPATH**/ ?>