<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center">
        <div class="row form-complet-bloc">
                <h3 class="text-center verif-ine-h1"><?php echo e(__('ETAPE 2: Complètion du formulaire d\'inscription.')); ?></h3>
                <div class="col">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <p class="text-center verif-ine-p"><?php echo e(__('Vérifiez l\'exactitude de vos informations, apportez des modifications si besoin et renseignez les champs vides.')); ?></p>
                        <div class="row">
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="ine">INE :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('INE')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="nom">Nom :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Nom')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="prenom">Prénom :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Prénom')); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="datenaissance">Date de Naissance :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="date" placeholder="<?php echo e(__('Date de Naissance')); ?>">

                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="lieunaissance">Lieu de Naissance :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Lieu de Naissance')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="pere">Père :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Père')); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="mere">Mère :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Mère')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="departement">Département :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Département')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="promotion">Promotion :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Promotion')); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="telephone">Téléphone :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="tel" placeholder="<?php echo e(__('Téléphone')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="email">Email :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="email" placeholder="<?php echo e(__('Email')); ?>">
                            </div>
                            <div class="col-sm-4 mt-2">
                                <label class="form-label text-label" for="adresse">Adresse :</label>
                                <input class="form-control verif-ine-input verif-ine-input:hover" type="text" placeholder="<?php echo e(__('Adresse')); ?>">
                            </div>
                        </div>
                        <div class="row mb-5">
                            <div class="col-sm-2 mt-2">
                                <button class="btn verif-ine-submit">
                                    <span><?php echo e(__('Next')); ?></span>
                                    <i class="bi bi-check"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED MORIBA\Desktop\entistmamou\entistmamou\resources\views/etudiants/inscriptions/formulaire-inscription.blade.php ENDPATH**/ ?>