<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header card-head">
            <h1 class="bg-card text-center text-white card-head"><i class="fa fa-cog me-1"></i>Paramètres</h1>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <?php if(session()->has('info')): ?>
                        <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                            <h5 class="text-center"><?php echo e(session('info')); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <i class="fa fa-check icon-deleted text-white"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-3"></div>
            </div>
            <div class="row">
                <div class="col-md-4 bg-card-button">
                    <a class="bg-card-button-a" data-bs-toggle="modal" data-bs-target="#smallModal1">
                        <h4 class="text-center bg-card-button-a"><i class="fa fa-calendar"></i><br>Sessions</h4>
                    </a>
                </div>
                <div class="col-md-4 bg-card-button">
                    <a class="bg-card-button-a" data-bs-toggle="modal" data-bs-target="#smallModal2">
                        <h4 class="text-center bg-card-button-a"><i class="fa fa-graduation-cap"></i><br>Promotions</h4>
                    </a>
                </div>
                <div class="col-md-4 bg-card-button">
                    <a class="bg-card-button-a" data-bs-toggle="modal" data-bs-target="#smallModal3">
                        <h4 class="text-center bg-card-button-a"><i class="fa fa-clone"></i><br>Semestres</h4>
                    </a>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-4">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center bg-light">Sessions</th>
                                <th class="text-center bg-light">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $anneeUnivs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anneeUniv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($anneeUniv->session); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('session.edit', $anneeUniv->id)); ?>"><i class="fa fa-edit btn-color-primary"></i></a>
                                        <a href="<?php echo e(route('session.delete', $anneeUniv->id)); ?>" data-bs-toggle="modal" data-bs-target="#verticalycentered1<?php echo e($anneeUniv->id); ?>"><i class="fa fa-trash text-danger"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td colspan="2" class="text-center"><p class="">Aucune session !</p></td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div>
                        <footer class="card-footer">
                            <?php echo e($anneeUnivs->links()); ?>

                        </footer>
                    </div>
                </div>
                <div class="col-md-4">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center bg-light">Promotions</th>
                                <th class="text-center bg-light">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($promotion->promotion); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('promotion.edit', $promotion->id)); ?>"><i class="fa fa-edit btn-color-primary"></i></a>
                                        <a href="<?php echo e(route('promotion.delete', $promotion->id)); ?>" data-bs-toggle="modal" data-bs-target="#verticalycentered2<?php echo e($promotion->id); ?>"><i class="fa fa-trash text-danger"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td colspan="2" class="text-center"><p class="">Aucune promotion !</p></td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div>
                        <footer class="card-footer">
                            <?php echo e($promotions->links()); ?>

                        </footer>
                    </div>
                </div>
                <div class="col-md-4">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center bg-light">Semestres</th>
                                <th class="text-center bg-light">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($semestre->semestre); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('semestre.edit', $semestre->id)); ?>"><i class="fa fa-edit btn-color-primary"></i></a>
                                        <a href="<?php echo e(route('semestre.delete', $semestre->id)); ?>" data-bs-toggle="modal" data-bs-target="#verticalycentered3<?php echo e($semestre->id); ?>"><i class="fa fa-trash text-danger"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td colspan="2" class="text-center"><p class="">Aucun semestre !</p></td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div>
                        <footer class="card-footer">
                            <?php echo e($semestres->links()); ?>

                        </footer>
                    </div>
                </div>
            </div>
            <!-- Ajout sesion -->
            <div class="modal fade" id="smallModal1" tabindex="-1">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header bg-card-modal">
                            <h3 class="modal-title">Ajout d'une session</h3>
                            <button type="button" class="bg-btn-close-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('session.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="row">
                                    <div class="col">
                                        <label for="session" class="label-control label-text">Session:</label>
                                        <input type="text" name="session" id="session" value="<?php echo e(old('session')); ?>" class="form-control border-input" placeholder="ex:2023-2024">
                                        <?php $__errorArgs = ['session'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class=" btn-fermer bg-danger text-white" data-bs-dismiss="modal"><i class="fa fa-times me-1"></i>Fermer</button>
                                        <button type="submit" class="btn-modal"><i class="fa fa-check me-1"></i>Enregistrer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> <!-- Fin ajout session-->
            <!-- Ajout promotion -->
            <div class="modal fade" id="smallModal2" tabindex="-1">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header bg-card-modal">
                            <h3 class="modal-title">Ajout d'une promotion</h3>
                            <button type="button" class="bg-btn-close-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('promotion.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="row">
                                    <div class="col">
                                        <label for="promotion" class="label-control label-text">Promotion:</label>
                                        <input type="text" name="promotion" id="promotion" value="<?php echo e(old('promotion')); ?>" class="form-control border-input" placeholder="ex:Promotion 15">
                                        <?php $__errorArgs = ['promotion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class=" btn-fermer bg-danger text-white" data-bs-dismiss="modal"><i class="fa fa-times me-1"></i>Fermer</button>
                                        <button type="submit" class="btn-modal"><i class="fa fa-check me-1"></i>Enregistrer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> <!-- Fin ajout promotion-->
            <!-- Ajout semestre -->
            <div class="modal fade" id="smallModal3" tabindex="-1">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header bg-card-modal">
                            <h3 class="modal-title">Ajout d'un semestre</h3>
                            <button type="button" class="bg-btn-close-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('semestre.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="row">
                                    <div class="col">
                                        <label for="semestre" class="label-control label-text">Semestre:</label>
                                        <input type="text" name="semestre" id="semestre" value="<?php echo e(old('semestre')); ?>" class="form-control border-input" placeholder="ex:Semestre 8">
                                        <?php $__errorArgs = ['semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class=" btn-fermer bg-danger text-white" data-bs-dismiss="modal"><i class="fa fa-times me-1"></i>Fermer</button>
                                        <button type="submit" class="btn-modal"><i class="fa fa-check me-1"></i>Enregistrer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> <!-- Fin ajout semestre-->
            <!-- Suppression session-->
            <?php $__currentLoopData = $anneeUnivs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anneeUniv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="verticalycentered1<?php echo e($anneeUniv->id); ?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title"><i class="fa fa-trash"></i> Suppression</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="text-center message-deleted">Voulez-vous vraiment effectuer la suppression de la session <?php echo e($anneeUniv->session); ?> ?</p>
                                <i class="fa fa-trash icon-deleted text-danger"></i>
                            </div>
                            <div class="modal-footer">
                                <a href="<?php echo e(route('session.delete', $anneeUniv->id)); ?>" class="btn btn-danger">Oui</a>
                                <button type="button" class="non-btn" data-bs-dismiss="modal">Non</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!-- Fin supression session -->
            <!-- Suppression promotion-->
            <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="verticalycentered2<?php echo e($promotion->id); ?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title"><i class="fa fa-trash"></i> Suppression</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="text-center message-deleted">Voulez-vous vraiment effectuer la suppression de la <?php echo e($promotion->promotion); ?> ?</p>
                                <i class="fa fa-trash icon-deleted text-danger"></i>
                            </div>
                            <div class="modal-footer">
                                <a href="<?php echo e(route('promotion.delete', $promotion->id)); ?>" class="btn btn-danger">Oui</a>
                                <button type="button" class="non-btn" data-bs-dismiss="modal">Non</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!-- Fin supression promotion -->
            <!-- Suppression semestre-->
            <?php $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="verticalycentered3<?php echo e($semestre->id); ?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title"><i class="fa fa-trash"></i> Suppression</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="text-center message-deleted">Voulez-vous vraiment effectuer la suppression du <?php echo e($semestre->semestre); ?> ?</p>
                                <i class="fa fa-trash icon-deleted text-danger"></i>
                            </div>
                            <div class="modal-footer">
                                <a href="<?php echo e(route('semestre.delete', $semestre->id)); ?>" class="btn btn-danger">Oui</a>
                                <button type="button" class="non-btn" data-bs-dismiss="modal">Non</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!-- Fin supression semestre -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-scolarite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED MORIBA\Desktop\entistmamou\entistmamou\resources\views/scolarite/parametres/parametre.blade.php ENDPATH**/ ?>